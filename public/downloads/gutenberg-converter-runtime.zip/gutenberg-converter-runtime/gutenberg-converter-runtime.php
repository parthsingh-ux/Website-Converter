<?php
/**
 * Plugin Name: Gutenberg Converter Runtime
 * Description: Imports converted block patterns and external CSS/JS while preserving source markup.
 * Version: 2.1.0
 * Requires at least: 6.6
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function gcb_can_import() {
    return current_user_can( 'manage_options' ) && current_user_can( 'unfiltered_html' );
}
function gcb_register_blocks() {
    wp_register_script( 'gcb-blocks', plugins_url( 'assets/blocks.js', __FILE__ ), array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components' ), '2.1.0', true );
    $common = array(
        'api_version' => 3,
        'editor_script' => 'gcb-blocks',
        'supports' => array( 'html' => false, 'customClassName' => true, 'anchor' => false, 'color' => false, 'typography' => false, 'spacing' => false, 'layout' => false ),
        'attributes' => array(
            'tagName' => array( 'type' => 'string', 'default' => 'div' ),
            'htmlAttributes' => array( 'type' => 'object', 'default' => new stdClass() ),
            'className' => array( 'type' => 'string' ),
        ),
    );
    register_block_type( 'gcb/element', $common );
    $text = $common;
    $text['attributes']['content'] = array( 'type' => 'string', 'default' => '' );
    register_block_type( 'gcb/text', $text );
    $image = $common;
    unset( $image['attributes']['tagName'] );
    register_block_type( 'gcb/image', $image );
    register_block_type( 'gcb/markup', array(
        'api_version' => 3,
        'editor_script' => 'gcb-blocks',
        'supports' => array( 'html' => false, 'customClassName' => false, 'className' => false ),
        'attributes' => array( 'content' => array( 'type' => 'string', 'default' => '' ) ),
    ) );
}
add_action( 'init', 'gcb_register_blocks' );

function gcb_menu() {
    add_management_page( 'Gutenberg Converter Import', 'Gutenberg Converter Import', 'manage_options', 'gcb-import', 'gcb_import_page' );
}
add_action( 'admin_menu', 'gcb_menu' );
function gcb_import_page() {
    if ( ! gcb_can_import() ) {
        wp_die( esc_html__( 'Importing source HTML and JavaScript requires an administrator with unfiltered HTML permission.', 'gcb' ) );
    }
    echo '<div class="wrap"><h1>Gutenberg Converter Import</h1><p>Choose the JSON export from Gutenberg Converter 2. The importer saves its CSS and JavaScript as external files and creates an unsynced pattern.</p><p>Upload referenced images separately and set their real URLs in the converter. Existing page copies are not replaced when importing a new revision.</p><input id="gcb-file" type="file" accept=".json,application/json"><p><button id="gcb-import-button" class="button button-primary" type="button">Import pattern and assets</button></p><p id="gcb-status" role="status" aria-live="polite"></p></div>';
}
function gcb_admin_assets( $hook ) {
    if ( 'tools_page_gcb-import' !== $hook ) { return; }
    wp_enqueue_script( 'gcb-import', plugins_url( 'assets/import.js', __FILE__ ), array( 'gcb-blocks', 'wp-block-library' ), '2.1.0', true );
    wp_localize_script( 'gcb-import', 'gcbImport', array( 'restUrl' => rest_url( 'gcb/v1/import' ), 'nonce' => wp_create_nonce( 'wp_rest' ) ) );
}
add_action( 'admin_enqueue_scripts', 'gcb_admin_assets' );
function gcb_routes() {
    register_rest_route( 'gcb/v1', '/import', array( 'methods' => array( 'POST', 'OPTIONS' ), 'callback' => 'gcb_import_bundle', 'permission_callback' => 'gcb_can_import' ) );
}
add_action( 'rest_api_init', 'gcb_routes' );

function gcb_cors_headers() {
    if ( isset( $_SERVER['HTTP_ORIGIN'] ) ) {
        header( "Access-Control-Allow-Origin: " . $_SERVER['HTTP_ORIGIN'] );
        header( "Access-Control-Allow-Credentials: true" );
        header( "Access-Control-Allow-Methods: GET, POST, OPTIONS" );
        header( "Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce" );
    }
    if ( 'OPTIONS' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
        status_header( 200 );
        exit;
    }
}
add_action( 'init', 'gcb_cors_headers' );

function gcb_check_blocks( $blocks, $depth = 0 ) {
    if ( $depth > 64 ) { return false; }
    $allowed = array( 'core/heading', 'core/paragraph', 'core/html', 'gcb/element', 'gcb/text', 'gcb/image', 'gcb/markup' );
    foreach ( $blocks as $block ) {
        if ( ! $block['blockName'] && ! trim( $block['innerHTML'] ) ) { continue; }
        if ( ! in_array( $block['blockName'], $allowed, true ) || ! gcb_check_blocks( $block['innerBlocks'], $depth + 1 ) ) { return false; }
    }
    return true;
}
function gcb_write_asset( $file, $bytes ) {
    if ( file_exists( $file ) && hash_equals( hash( 'sha256', $bytes ), hash_file( 'sha256', $file ) ) ) {
        return true;
    }
    
    $written = file_put_contents( $file, $bytes, LOCK_EX );
    if ( false !== $written && strlen( $bytes ) === $written ) {
        return true;
    }

    if ( ! function_exists( 'wp_tempnam' ) ) { require_once ABSPATH . 'wp-admin/includes/file.php'; }
    $dir = dirname( $file );
    if ( ! wp_mkdir_p( $dir ) ) { return false; }
    $temp = wp_tempnam( basename( $file ), $dir );
    if ( ! $temp ) { return false; }

    $written_temp = file_put_contents( $temp, $bytes, LOCK_EX );
    if ( strlen( $bytes ) !== $written_temp || ! rename( $temp, $file ) ) {
        if ( file_exists( $temp ) ) { unlink( $temp ); }
        return false;
    }

    return true;
}
function gcb_import_media_to_library( $filename, $base64_data, $parent_post_id = 0 ) {
    if ( empty( $base64_data ) || ! is_string( $base64_data ) ) { return false; }
    if ( ! preg_match( '/^data:image\/(png|jpeg|jpg|webp|gif|svg\+xml);base64,([A-Za-z0-9+\/=]+)$/i', $base64_data, $m ) ) {
        return false;
    }

    $ext = ( 'svg+xml' === $m[1] ) ? 'svg' : ( 'jpeg' === $m[1] ? 'jpg' : $m[1] );
    $bytes = base64_decode( $m[2] );
    if ( false === $bytes ) { return false; }

    $raw_filename = pathinfo( parse_url( $filename, PHP_URL_PATH ) ?? $filename, PATHINFO_BASENAME );
    $clean_name = sanitize_file_name( strtok( $raw_filename, '?' ) );
    if ( empty( $clean_name ) || false === strpos( $clean_name, '.' ) ) {
        $clean_name = 'image_' . date( 'Ymd_His' ) . '.' . $ext;
    }

    if ( ! function_exists( 'wp_upload_bits' ) ) {
        require_once( ABSPATH . 'wp-admin/includes/file.php' );
    }

    // Write file using wp_upload_bits into WP Uploads (/wp-content/uploads/YYYY/MM/filename)
    $upload = wp_upload_bits( $clean_name, null, $bytes );
    if ( ! empty( $upload['error'] ) || empty( $upload['file'] ) ) {
        return false;
    }

    $file_path = $upload['file'];
    $file_url = $upload['url'];
    $wp_filetype = wp_check_filetype( $clean_name, null );

    global $wpdb;
    $attachment_id = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE guid=%s", $file_url ) );

    if ( ! $attachment_id ) {
        $attachment = array(
            'post_mime_type' => $wp_filetype['type'] ?: 'image/jpeg',
            'post_title'     => preg_replace( '/\.[^.]+$/', '', $clean_name ),
            'post_content'   => '',
            'post_status'    => 'inherit'
        );
        $attachment_id = wp_insert_attachment( $attachment, $file_path, $parent_post_id );

        if ( ! is_wp_error( $attachment_id ) && $attachment_id > 0 ) {
            require_once( ABSPATH . 'wp-admin/includes/image.php' );
            $attach_data = wp_generate_attachment_metadata( $attachment_id, $file_path );
            wp_update_attachment_metadata( $attachment_id, $attach_data );
        }
    }

    return array(
        'id'  => $attachment_id,
        'url' => $file_url,
    );
}

function gcb_fetch_remote_image( $url ) {
    $url = trim( $url );
    if ( empty( $url ) || '#' === $url[0] ) return false;

    if ( 0 === strpos( $url, '//' ) ) {
        $url = 'https:' . $url;
    }
    if ( ! preg_match( '/^https?:\/\//i', $url ) ) {
        return false;
    }

    $parsed = parse_url( $url );
    $host = $parsed['host'] ?? '';
    $scheme = $parsed['scheme'] ?? 'https';
    $referer = $scheme . '://' . $host . '/';

    $args = array(
        'timeout'     => 15,
        'sslverify'   => false,
        'redirection' => 5,
        'user-agent'  => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'headers'     => array(
            'Accept'          => 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
            'Accept-Language' => 'en-US,en;q=0.9',
            'Referer'         => $referer,
        ),
    );

    $response_body = false;
    $content_type = '';

    if ( function_exists( 'wp_remote_get' ) ) {
        $res = wp_remote_get( $url, $args );
        if ( ! is_wp_error( $res ) && 200 === wp_remote_retrieve_response_code( $res ) ) {
            $response_body = wp_remote_retrieve_body( $res );
            $content_type = wp_remote_retrieve_header( $res, 'content-type' );
        }
    }

    if ( empty( $response_body ) && function_exists( 'wp_remote_get' ) ) {
        $alt_url = ( 'https' === $scheme ) ? 'http://' . substr( $url, 8 ) : 'https://' . substr( $url, 7 );
        $res = wp_remote_get( $alt_url, $args );
        if ( ! is_wp_error( $res ) && 200 === wp_remote_retrieve_response_code( $res ) ) {
            $response_body = wp_remote_retrieve_body( $res );
            $content_type = wp_remote_retrieve_header( $res, 'content-type' );
        }
    }

    if ( empty( $response_body ) && function_exists( 'curl_init' ) ) {
        $ch = curl_init();
        curl_setopt( $ch, CURLOPT_URL, $url );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 0 );
        curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
        curl_setopt( $ch, CURLOPT_MAXREDIRS, 5 );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 15 );
        curl_setopt( $ch, CURLOPT_USERAGENT, $args['user-agent'] );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
            'Accept: image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
            'Referer: ' . $referer,
        ) );
        $curl_body = curl_exec( $ch );
        $http_code = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
        $c_type = curl_getinfo( $ch, CURLINFO_CONTENT_TYPE );
        curl_close( $ch );

        if ( 200 === $http_code && ! empty( $curl_body ) ) {
            $response_body = $curl_body;
            $content_type = $c_type;
        }
    }

    if ( empty( $response_body ) ) {
        return false;
    }

    $path = parse_url( $url, PHP_URL_PATH ) ?? '';
    $raw_filename = pathinfo( $path, PATHINFO_BASENAME );
    $ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
    $ext = strtok( $ext, '?' );

    $mime_map = array(
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',
        'image/svg+xml' => 'svg',
        'image/avif' => 'avif',
        'image/x-icon' => 'ico',
        'image/bmp'  => 'bmp',
    );

    if ( empty( $ext ) || ! in_array( $ext, array( 'jpg', 'jpeg', 'png', 'webp', 'gif', 'svg', 'avif', 'ico', 'bmp' ), true ) ) {
        foreach ( $mime_map as $mime => $mext ) {
            if ( false !== strpos( strtolower( $content_type ), $mime ) ) {
                $ext = $mext;
                break;
            }
        }
    }
    if ( empty( $ext ) ) {
        $ext = 'jpg';
    }

    $clean_name = sanitize_file_name( strtok( $raw_filename, '?' ) );
    if ( empty( $clean_name ) || false === strpos( $clean_name, '.' ) ) {
        $clean_name = 'image_' . date( 'Ymd_His' ) . '.' . $ext;
    }

    return array(
        'bytes'    => $response_body,
        'filename' => $clean_name,
        'ext'      => $ext,
    );
}

function gcb_find_existing_attachment_url( $filename ) {
    if ( empty( $filename ) ) { return false; }
    global $wpdb;

    $raw = pathinfo( parse_url( $filename, PHP_URL_PATH ) ?? $filename, PATHINFO_BASENAME );
    $clean = strtok( $raw, '?' );
    $slug = preg_replace( '/\.[^.]+$/', '', $clean );
    if ( empty( $slug ) ) { return false; }

    $base_slug = preg_replace( '/-[0-9]+$/', '', $slug );

    // 1. Exact match on post_title or guid filename
    $query = $wpdb->prepare(
        "SELECT guid FROM {$wpdb->posts} 
         WHERE post_type = 'attachment' 
         AND (post_title = %s OR guid LIKE %s) 
         ORDER BY ID DESC LIMIT 1",
        $slug,
        '%' . $wpdb->esc_like( $clean )
    );
    $url = $wpdb->get_var( $query );
    if ( ! empty( $url ) ) { return $url; }

    // 2. Fuzzy match on base slug (e.g. image-7-1, image-7-2)
    $query2 = $wpdb->prepare(
        "SELECT guid FROM {$wpdb->posts} 
         WHERE post_type = 'attachment' 
         AND (post_title LIKE %s OR guid LIKE %s) 
         ORDER BY ID DESC LIMIT 1",
        $wpdb->esc_like( $base_slug ) . '%',
        '%' . $wpdb->esc_like( $base_slug ) . '%'
    );
    $url2 = $wpdb->get_var( $query2 );
    if ( ! empty( $url2 ) ) { return $url2; }

    return false;
}

function gcb_find_local_upload_file( $url ) {
    $uploads = wp_upload_dir();
    $basedir = rtrim( $uploads['basedir'], '/' );
    $baseurl = rtrim( $uploads['baseurl'], '/' );

    $filename = pathinfo( parse_url( $url, PHP_URL_PATH ) ?? $url, PATHINFO_BASENAME );
    $clean_filename = strtok( $filename, '?' );
    if ( empty( $clean_filename ) ) { return false; }

    $base_slug = preg_replace( '/\.[^.]+$/', '', $clean_filename );
    $base_slug_clean = preg_replace( '/-[0-9]+$/', '', $base_slug );
    $ext = pathinfo( $clean_filename, PATHINFO_EXTENSION ) ?: 'jpg';

    // 1. Direct path check if URL contains /wp-content/uploads/
    if ( false !== strpos( $url, 'wp-content/uploads/' ) ) {
        $rel = substr( $url, strpos( $url, 'wp-content/uploads/' ) + strlen( 'wp-content/uploads/' ) );
        $rel = strtok( $rel, '?' );
        $check_path = $basedir . '/' . ltrim( $rel, '/' );
        if ( file_exists( $check_path ) && filesize( $check_path ) > 0 ) {
            return $baseurl . '/' . ltrim( $rel, '/' );
        }
    }

    // 2. Check YYYY/MM and root uploads folders for filename or filename-1
    $year = date( 'Y' );
    $month = date( 'm' );
    $year_month_dir = $basedir . '/' . $year . '/' . $month;

    $test_names = array(
        $clean_filename,
        $base_slug . '-1.' . $ext,
        $base_slug . '-2.' . $ext,
        $base_slug_clean . '-1.' . $ext,
        $base_slug_clean . '-2.' . $ext,
    );

    foreach ( array_unique( $test_names ) as $tname ) {
        $p = $year_month_dir . '/' . $tname;
        if ( file_exists( $p ) && filesize( $p ) > 0 ) {
            return $baseurl . '/' . $year . '/' . $month . '/' . $tname;
        }
        $p_root = $basedir . '/' . $tname;
        if ( file_exists( $p_root ) && filesize( $p_root ) > 0 ) {
            return $baseurl . '/' . $tname;
        }
    }

    return false;
}

function gcb_import_media_from_url( $url, $parent_post_id = 0 ) {
    $url = trim( $url );
    if ( empty( $url ) || '#' === $url[0] ) { return false; }
    if ( 0 === strpos( $url, 'data:image/' ) ) {
        return gcb_import_media_to_library( '', $url, $parent_post_id );
    }

    // 1. FAST LOCAL DISK CHECK (0.1ms)
    $local_file_url = gcb_find_local_upload_file( $url );
    if ( ! empty( $local_file_url ) ) {
        return array( 'url' => $local_file_url );
    }

    // 2. FAST DB ATTACHMENT CHECK (1ms)
    $existing_url = gcb_find_existing_attachment_url( $url );
    if ( ! empty( $existing_url ) ) {
        return array( 'url' => $existing_url );
    }

    // 3. Prevent self-fetching loops on target site domain (avoids WPEngine 502 worker exhaustion)
    $target_site_url = rtrim( site_url(), '/' );
    if ( false !== strpos( $url, $target_site_url ) || 0 === strpos( $url, '/' ) ) {
        return false;
    }

    // 4. EXTERNAL REMOTE FETCH
    $fetched = gcb_fetch_remote_image( $url );
    if ( ! $fetched || empty( $fetched['bytes'] ) ) {
        return false;
    }

    if ( ! function_exists( 'wp_upload_bits' ) ) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
    }

    $upload = wp_upload_bits( $fetched['filename'], null, $fetched['bytes'] );
    if ( ! empty( $upload['error'] ) || empty( $upload['file'] ) ) {
        return false;
    }

    $file_path = $upload['file'];
    $file_url = $upload['url'];
    $wp_filetype = wp_check_filetype( $fetched['filename'], null );

    global $wpdb;
    $attachment_id = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE guid=%s", $file_url ) );

    if ( ! $attachment_id ) {
        $attachment = array(
            'post_mime_type' => $wp_filetype['type'] ?: 'image/jpeg',
            'post_title'     => preg_replace( '/\.[^.]+$/', '', $fetched['filename'] ),
            'post_content'   => '',
            'post_status'    => 'inherit'
        );
        $attachment_id = wp_insert_attachment( $attachment, $file_path, $parent_post_id );

        if ( ! is_wp_error( $attachment_id ) && $attachment_id > 0 ) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
            $attach_data = wp_generate_attachment_metadata( $attachment_id, $file_path );
            wp_update_attachment_metadata( $attachment_id, $attach_data );
        }
    }

    return array(
        'id'  => $attachment_id,
        'url' => $file_url,
    );
}

function gcb_localize_media_url( $url, $media_dir, $media_url, $parent_post_id = 0 ) {
    $url = trim( $url );
    if ( empty( $url ) || '#' === $url[0] ) {
        return $url;
    }

    // Try importing directly into WP Media Library first (/wp-content/uploads/YYYY/MM/filename)
    $imported = gcb_import_media_from_url( $url, $parent_post_id );
    if ( $imported && ! empty( $imported['url'] ) ) {
        return $imported['url'];
    }

    // Fallback: Use wp_upload_bits into /wp-content/uploads/YYYY/MM/filename
    $fetch_url = $url;
    if ( 0 === strpos( $url, '//' ) ) {
        $fetch_url = 'https:' . $url;
    } elseif ( ! preg_match( '/^https?:\/\//i', $url ) ) {
        $target_site_url = rtrim( site_url(), '/' );
        $fetch_url = $target_site_url . '/' . ltrim( $url, '/' );
    }

    if ( preg_match( '/^https?:\/\//i', $fetch_url ) ) {
        $fetched = gcb_fetch_remote_image( $fetch_url );
        if ( $fetched && ! empty( $fetched['bytes'] ) ) {
            if ( ! function_exists( 'wp_upload_bits' ) ) {
                require_once ABSPATH . 'wp-admin/includes/file.php';
            }
            $upload = wp_upload_bits( $fetched['filename'], null, $fetched['bytes'] );
            if ( empty( $upload['error'] ) && ! empty( $upload['url'] ) ) {
                return $upload['url'];
            }
        }
    }

    return $url;
}

function gcb_process_all_media( &$content, &$css, $images_array = array(), $parent_post_id = 0 ) {
    if ( ! is_string( $content ) ) { return; }
    $uploads = wp_upload_dir();
    $media_dir = trailingslashit( $uploads['basedir'] ) . 'gutenberg-converter/media';
    $media_url = trailingslashit( $uploads['baseurl'] ) . 'gutenberg-converter/media';

    // 0. Import uploaded image assets array into WordPress Media Library
    if ( is_array( $images_array ) && ! empty( $images_array ) ) {
        foreach ( $images_array as $asset ) {
            if ( empty( $asset['data'] ) || empty( $asset['filename'] ) ) { continue; }
            $attached = gcb_import_media_to_library( $asset['filename'], $asset['data'], $parent_post_id );
            if ( $attached && ! empty( $attached['url'] ) ) {
                $new_url = $attached['url'];
                
                $names_to_match = array_unique( array(
                    $asset['filename'],
                    urldecode( $asset['filename'] ),
                    urlencode( $asset['filename'] )
                ) );

                foreach ( $names_to_match as $name ) {
                    $fname = preg_quote( $name, '/' );
                    
                    // Replace matching filename in src="..."
                    $content = preg_replace( '/(src=["\'])[^"\'\s>]*' . $fname . '(?:\?[^"\'\s>]*)?(["\'])/i', '$1' . $new_url . '$2', $content );
                    
                    // Replace matching filename in srcset="..."
                    $content = preg_replace( '/(srcset=["\'])[^"\'\>]*' . $fname . '(?:\?[^"\'\>]*)*(["\'])/i', '$1' . $new_url . '$2', $content );

                    // Replace matching filename in url(...)
                    $content = preg_replace( '/url\(\s*["\']?[^"\')]*' . $fname . '(?:\?[^"\')]*)*["\']?\s*\)/i', 'url("' . $new_url . '")', $content );
                    if ( is_string( $css ) ) {
                        $css = preg_replace( '/url\(\s*["\']?[^"\')]*' . $fname . '(?:\?[^"\')]*)*["\']?\s*\)/i', 'url("' . $new_url . '")', $css );
                    }
                }

                // Replace base64 data string directly if matched
                if ( ! empty( $asset['data'] ) ) {
                    $content = str_replace( $asset['data'], $new_url, $content );
                    if ( is_string( $css ) ) {
                        $css = str_replace( $asset['data'], $new_url, $css );
                    }
                }
            }
        }
    }

    // 1. Replace remaining src="..."
    $content = preg_replace_callback( '/(src=["\'])([^"\'\s>]+)(["\'])/i', function( $m ) use ( $media_dir, $media_url, $parent_post_id ) {
        return $m[1] . gcb_localize_media_url( $m[2], $media_dir, $media_url, $parent_post_id ) . $m[3];
    }, $content );

    // 2. Replace remaining srcset="..."
    $content = preg_replace_callback( '/(srcset=["\'])([^"\'\>]+)(["\'])/i', function( $m ) use ( $media_dir, $media_url, $parent_post_id ) {
        $parts = explode( ',', $m[2] );
        $new_parts = array();
        foreach ( $parts as $part ) {
            $part = trim( $part );
            if ( empty( $part ) ) { continue; }
            $tokens = preg_split( '/\s+/', $part );
            if ( ! empty( $tokens[0] ) ) {
                $tokens[0] = gcb_localize_media_url( $tokens[0], $media_dir, $media_url, $parent_post_id );
            }
            $new_parts[] = implode( ' ', $tokens );
        }
        return $m[1] . implode( ', ', $new_parts ) . $m[3];
    }, $content );

    // 3. Replace remaining url(...) in content and CSS
    $replace_urls = function( $text ) use ( $media_dir, $media_url, $parent_post_id ) {
        return preg_replace_callback( '/url\(\s*(?:(["\'])(.*?)\1|([^)]+))\s*\)/i', function( $m ) use ( $media_dir, $media_url, $parent_post_id ) {
            $raw = ! empty( $m[1] ) ? $m[2] : $m[3];
            $quote = ! empty( $m[1] ) ? $m[1] : '"';
            $new_url = gcb_localize_media_url( trim( $raw ), $media_dir, $media_url, $parent_post_id );
            return 'url(' . $quote . $new_url . $quote . ')';
        }, $text );
    };

    $content = $replace_urls( $content );
    if ( is_string( $css ) ) {
        $css = $replace_urls( $css );
    }
}


function gcb_import_bundle( $request ) {
    $d = $request->get_json_params();
    if ( ! is_array( $d ) || ( $d['format'] ?? '' ) !== 'gcb-bundle' || ( $d['formatVersion'] ?? 0 ) !== 1 ) {
        return new WP_Error( 'gcb_format', 'Use a JSON export from Gutenberg Converter 2.', array( 'status' => 400 ) );
    }
    foreach ( array( 'patternScopeId', 'content', 'patternCss', 'patternJs', 'title' ) as $key ) {
        if ( ! isset( $d[ $key ] ) || ! is_string( $d[ $key ] ) || strlen( $d[ $key ] ) > 8 * MB_IN_BYTES ) {
            return new WP_Error( 'gcb_field', 'Missing, invalid or oversized field: ' . $key, array( 'status' => 400 ) );
        }
    }
    $id = $d['patternScopeId'];
    if ( ! preg_match( '/^gcb-[a-f0-9]{16}$/D', $id ) ) {
        return new WP_Error( 'gcb_dependencies', 'Invalid asset ID or pattern scope.', array( 'status' => 400 ) );
    }

    $uploads = wp_upload_dir();
    if ( $uploads['error'] ) { return new WP_Error( 'gcb_uploads', $uploads['error'], array( 'status' => 500 ) ); }
    $dir = trailingslashit( $uploads['basedir'] ) . 'gutenberg-converter';
    if ( ! wp_mkdir_p( $dir ) ) { return new WP_Error( 'gcb_directory', 'Could not create the converted asset directory.', array( 'status' => 500 ) ); }
    
    // Process all media in content & CSS before saving asset files
    $processed_content = $d['content'];
    $processed_css = $d['patternCss'];
    $images_array = is_array( $d['imagesArray'] ?? null ) ? $d['imagesArray'] : array();
    gcb_process_all_media( $processed_content, $processed_css, $images_array );

    $registry = get_option( 'gcb_asset_registry', array() );
    $asset_hash = hash( 'sha256', $processed_css . "\0" . $d['patternJs'] );
    
    if ( ! gcb_write_asset( $dir . '/' . $id . '.css', $processed_css ) || ( trim( $d['patternJs'] ) && ! gcb_write_asset( $dir . '/' . $id . '.js', $d['patternJs'] ) ) ) {
        return new WP_Error( 'gcb_write', 'Could not save the external assets. Check uploads directory permissions.', array( 'status' => 500 ) );
    }

    // 1. Create or Update Pattern (wp_block)
    $post = array(
        'post_type' => 'wp_block',
        'post_status' => 'publish',
        'post_title' => sanitize_text_field( $d['title'] ),
        'post_content' => $processed_content
    );
    if ( isset( $registry[ $id ]['pattern_id'] ) && 'wp_block' === get_post_type( $registry[ $id ]['pattern_id'] ) ) {
        $post['ID'] = $registry[ $id ]['pattern_id'];
    }
    $post_id = wp_insert_post( wp_slash( $post ), true );
    if ( is_wp_error( $post_id ) ) { return $post_id; }

    update_post_meta( $post_id, 'wp_pattern_sync_status', 'unsynced' );
    update_post_meta( $post_id, '_gcb_asset_id', $id );

    $registry[ $id ] = array(
        'asset_hash' => $asset_hash,
        'has_js' => (bool) trim( $d['patternJs'] ),
        'pattern_id' => $post_id,
        'title' => $post['post_title']
    );

    $response = array(
        'patternId' => $post_id,
        'title' => $post['post_title'],
        'editUrl' => admin_url( 'post.php?post=' . $post_id . '&action=edit' )
    );

    // 2. Create or Update Page (page)
    if ( ! empty( $d['createPage'] ) ) {
        $page_title = ! empty( $d['pageTitle'] ) ? sanitize_text_field( $d['pageTitle'] ) : $post['post_title'];
        $page_status = ! empty( $d['pageStatus'] ) && in_array( $d['pageStatus'], array( 'publish', 'draft' ), true ) ? $d['pageStatus'] : 'publish';
        
        $page_post = array(
            'post_type' => 'page',
            'post_status' => $page_status,
            'post_title' => $page_title,
            'post_content' => $processed_content
        );
        if ( isset( $registry[ $id ]['page_id'] ) && 'page' === get_post_type( $registry[ $id ]['page_id'] ) ) {
            $page_post['ID'] = $registry[ $id ]['page_id'];
        }
        $page_id = wp_insert_post( wp_slash( $page_post ), true );
        if ( ! is_wp_error( $page_id ) ) {
            $registry[ $id ]['page_id'] = $page_id;
            $response['pageId'] = $page_id;
            $response['pageUrl'] = get_permalink( $page_id );
            $response['pageEditUrl'] = admin_url( 'post.php?post=' . $page_id . '&action=edit' );
        }
    }

    update_option( 'gcb_asset_registry', $registry, false );
    return rest_ensure_response( $response );
}

function gcb_ids_in_blocks( $blocks, &$ids, &$seen, $depth = 0 ) {
    if ( $depth > 64 ) { return; }
    $registry = get_option( 'gcb_asset_registry', array() );
    foreach ( $blocks as $block ) {
        $classes = preg_split( '/\s+/', $block['attrs']['className'] ?? '' );
        foreach ( $classes as $class ) { if ( isset( $registry[ $class ] ) ) { $ids[ $class ] = true; } }
        if ( 'core/block' === $block['blockName'] && ! empty( $block['attrs']['ref'] ) && empty( $seen[ $block['attrs']['ref'] ] ) ) {
            $seen[ $block['attrs']['ref'] ] = true;
            $post = get_post( $block['attrs']['ref'] );
            if ( $post ) { gcb_ids_in_blocks( parse_blocks( $post->post_content ), $ids, $seen, $depth + 1 ); }
        }
        gcb_ids_in_blocks( $block['innerBlocks'], $ids, $seen, $depth + 1 );
    }
}
function gcb_enqueue_id( $id, $frontend = true ) {
    $registry = get_option( 'gcb_asset_registry', array() );
    if ( ! isset( $registry[ $id ] ) ) { return; }
    $uploads = wp_upload_dir();
    $url = trailingslashit( $uploads['baseurl'] ) . 'gutenberg-converter/' . $id;
    wp_enqueue_style( $id, $url . '.css', array(), $registry[ $id ]['asset_hash'] );
    if ( $frontend && $registry[ $id ]['has_js'] ) { wp_enqueue_script( $id, $url . '.js', array(), $registry[ $id ]['asset_hash'], true ); }
}
function gcb_enqueue_assets() {
    $registry = get_option( 'gcb_asset_registry', array() );
    if ( is_admin() ) {
        // All imported CSS is available for new insertions and pattern previews.
        foreach ( array_keys( $registry ) as $id ) { gcb_enqueue_id( $id, false ); }
        return;
    }
    global $wp_query;
    $ids = $seen = array();
    foreach ( (array) ( $wp_query->posts ?? array() ) as $post ) {
        if ( $post instanceof WP_Post ) { gcb_ids_in_blocks( parse_blocks( $post->post_content ), $ids, $seen ); }
    }
    foreach ( array_keys( $ids ) as $id ) { gcb_enqueue_id( $id ); }
}
add_action( 'enqueue_block_assets', 'gcb_enqueue_assets', 20 );
function gcb_render_assets( $content, $block ) {
    if ( is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return $content; }
    $registry = get_option( 'gcb_asset_registry', array() );
    foreach ( preg_split( '/\s+/', $block['attrs']['className'] ?? '' ) as $id ) {
        if ( ! isset( $registry[ $id ] ) ) { continue; }
        gcb_enqueue_id( $id );
        // Covers template parts and dynamically rendered content absent from the
        // main query. Output an external link once, never an inline stylesheet.
        if ( did_action( 'wp_head' ) && ! wp_style_is( $id, 'done' ) ) {
            ob_start(); wp_print_styles( array( $id ) ); $content = ob_get_clean() . $content;
        }
    }
    return $content;
}
add_filter( 'render_block', 'gcb_render_assets', 20, 2 );
